# Descripción breve del programa:
# Función para calcular una métrica de similitud entre dos cadenas basadas en las subcadenas comunes más largas.
# Autor: Fernando Maggi Llerandi | A01736935
# Fecha de creación/modificación: 30/10/2024

from sumCommonSubstringLengths import sumCommonSubstringLengths

def similarityMetric(s1, s2):
    """
    Calcula una métrica de similitud entre dos cadenas dadas en función de la suma de las longitudes 
    de las subcadenas comunes más largas.
    
    La función obtiene la longitud total de las subcadenas comunes de mayor longitud entre las dos cadenas 
    y la divide por la longitud de la cadena más larga, proporcionando un valor de similitud normalizado entre 0 y 1.
    
    Parámetros:
    - s1 (str): Primera cadena de texto para comparar.
    - s2 (str): Segunda cadena de texto para comparar.
    
    Retorna:
    - float: Valor de similitud entre las dos cadenas, en el rango de 0 a 1.
    """
    # Suma las longitudes de las subcadenas comunes más largas entre s1 y s2
    sumLcp = sumCommonSubstringLengths(s1, s2)
    
    # Determina la longitud máxima entre las dos cadenas
    maxLen = max(len(s1), len(s2))
    
    # Calcula la métrica de similitud, evitando división por cero
    return sumLcp / maxLen if maxLen > 0 else 0