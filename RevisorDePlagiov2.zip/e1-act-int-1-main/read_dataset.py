# Descripción:
# Función para leer archivos de texto en un directorio específico, almacenando el contenido en un diccionario.
# Autor: Fernando Maggi Llerandi | A01736935
# Fecha de creación/modificación: 30/10/2024

import os

def readDataset(directory):
    """
    Lee todos los archivos de texto (.txt) en un directorio dado y almacena su contenido en un diccionario.
    
    La función itera sobre los archivos en el directorio especificado, ignorando aquellos que están ocultos o no 
    tienen extensión .txt. Intenta leer cada archivo con codificación UTF-8; si falla, intenta con 'latin-1'.
    
    Parámetros:
    - directory (str): Ruta del directorio donde se encuentran los archivos .txt.
    
    Retorna:
    - dict: Un diccionario donde las claves son los nombres de los archivos y los valores son el contenido de cada archivo.
    """
    data = {}
    for filename in os.listdir(directory):
        if filename.startswith('.'):
            continue  # Ignora archivos ocultos
        if filename.endswith('.txt'):
            filepath = os.path.join(directory, filename)
            try:
                # Intenta abrir el archivo con codificación UTF-8
                with open(filepath, 'r', encoding='utf-8') as f:
                    data[filename] = f.read().strip() # Guarda el contenido del archivo sin espacios en blanco al inicio/final
            except UnicodeDecodeError:
                # Captura errores de codificación y reintenta con 'latin-1'
                print(f"Advertencia: No se pudo leer {filename} con codificación UTF-8.")
                print("Intentando con 'latin-1'...")
                with open(filepath, 'r', encoding='latin-1') as f:
                    data[filename] = f.read().strip() # Guarda el contenido del archivo sin espacios en blanco al inicio/final
    return data