# Descripción: Este archivo genera una matriz de similitud a partir de los resultados proporcionados.
# Autor: Rusbel Alejandro Morales Méndez - Matrícula: A01737814
# Fecha de creación/modificación: 31/10/2024

def generateSimilarityMatrix(results, files):
    # results (list): Lista de diccionarios que contienen los archivos y su métrica de similitud.
    # files (list): Lista de nombres de archivos.
    
    n = len(files)
    
    matrix = [[0] * n for _ in range(n)]  # Inicializa la matriz de similitud con ceros.
    
    fileIndex = {file: idx for idx, file in enumerate(files)}  # Crea un índice de archivos.
    
    for res in results:
        i = fileIndex[res['file1']]  # Obtiene el índice del primer archivo.
        j = fileIndex[res['file2']]  # Obtiene el índice del segundo archivo.
        
        matrix[i][j] = res['similarity_metric']  # Asigna la métrica de similitud a la matriz.
        matrix[j][i] = res['similarity_metric']  # Asigna la métrica de similitud simétrica a la matriz.
    
    return matrix