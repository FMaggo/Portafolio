# Programa para resaltar las similitudes y diferencias entre dos textos en la consola.
# Autor: Jonathan Armando Arredondo Hernandez
# Fecha de creación: 31/10/2024

from colorama import Fore, Style, init
from findSubsequences import findSubsequences
from longestCommonSubstring import longestCommonSubstring

# Inicializa colorama para reiniciar colores automáticamente
init(autoreset=True)

def highlightSimilarities(text1, text2):
    """
    Resalta las similitudes y diferencias entre dos textos en la consola.

    Parámetros:
    text1 (str): El primer texto de entrada.
    text2 (str): El segundo texto de entrada.

    Retorna:
    None
    """

    longestCommonSubstr = longestCommonSubstring(text1, text2)

    print("\n--- Substring más largo común ---")
    print(longestCommonSubstr)

    if longestCommonSubstr:
        positionsText1 = findSubsequences(text1, longestCommonSubstr)
        positionsText2 = findSubsequences(text2, longestCommonSubstr)

        highlightedText1 = ""
        index = 0
        # Resalta las posiciones del substring común en el texto 1
        for start in positionsText1:
            highlightedText1 += text1[index:start] + Fore.GREEN + text1[start:start + len(longestCommonSubstr)] + Style.RESET_ALL
            index = start + len(longestCommonSubstr)
        highlightedText1 += text1[index:]

        highlightedText2 = ""
        index = 0
        # Resalta las posiciones del substring común en el texto 2
        for start in positionsText2:
            highlightedText2 += text2[index:start] + Fore.GREEN + text2[start:start + len(longestCommonSubstr)] + Style.RESET_ALL
            index = start + len(longestCommonSubstr)
        highlightedText2 += text2[index:]

        print(Fore.CYAN + "\n--- Resaltado de Similitudes ---")
        print(Fore.YELLOW + "Texto 1:")
        print(highlightedText1)
        print(Fore.YELLOW + "\nTexto 2:")
        print(highlightedText2)
    else:
        print(Fore.RED + "No se encontraron substrings comunes significativos.")