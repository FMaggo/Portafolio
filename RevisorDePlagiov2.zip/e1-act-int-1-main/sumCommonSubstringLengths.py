# Programa para calcular la suma de las longitudes de subcadenas comunes entre dos cadenas.
# Autor: Jonathan Armando Arredondo Hernandez
# Fecha de creación: 29/10/2024
from computeLcpArray import computeLcpArray
from computeSuffixArray import computeSuffixArray


def sumCommonSubstringLengths(string1, string2):
    """
    Calcula la suma de las longitudes de subcadenas comunes entre dos cadenas.

    Parámetros:
    string1 (str): La primera cadena de entrada.
    string2 (str): La segunda cadena de entrada.

    Retorno:
    int: Suma de las longitudes de subcadenas comunes entre las dos cadenas.
    """

    separator = chr(0)
    combinedString = string1 + separator + string2
    suffixArray = computeSuffixArray(combinedString)
    lcpArray = computeLcpArray(combinedString, suffixArray)

    sumLcp = 0
    lengthString1 = len(string1)

    # Recorrer el array de sufijos y sumar la longitud de las subcadenas comunes
    for index in range(1, len(suffixArray)):
        isPrevInString1 = suffixArray[index - 1] < lengthString1
        isCurrInString1 = suffixArray[index] < lengthString1

        # Solo sumar la longitud de la subcadena común si una cadena pertenece a string1 y la otra a string2
        if isPrevInString1 != isCurrInString1:
            sumLcp += lcpArray[index - 1]

    return sumLcp
