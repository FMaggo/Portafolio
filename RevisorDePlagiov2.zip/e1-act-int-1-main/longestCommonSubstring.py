# Programa para encontrar la subcadena comun mas larga entre dos cadenas.
# Autor: Jonathan Armando Arredondo Hernandez y Diego Javier Solorzano Trinidad
# Fecha de creación: 31/10/2024

def longestCommonSubstring(string1, string2):
    """
    Encuentra la subcadena común más larga entre dos cadenas.

    Parametros:
    string1 (str): La primera cadena de entrada.
    string2 (str): La segunda cadena de entrada.

    Retorna:
    str: La subcadena común más larga entre las dos cadenas.
    """

    lengthString1, lengthString2 = len(string1), len(string2)
    maxLength = 0
    endIndexString1 = 0

    # Matriz par almacenar para la longitud de subcadenas comunes
    dpMatrix = [[0] * (lengthString2 + 1) for _ in range(lengthString1 + 1)]

    # Recorrer las matrices para encontrar la subcadena común más larga
    for i in range(1, lengthString1 + 1):
        for j in range(1, lengthString2 + 1):
            if string1[i - 1] == string2[j - 1]:
                dpMatrix[i][j] = dpMatrix[i - 1][j - 1] + 1
                if dpMatrix[i][j] > maxLength:
                    maxLength = dpMatrix[i][j]
                    endIndexString1 = i
            else:
                dpMatrix[i][j] = 0

    return string1[endIndexString1 - maxLength: endIndexString1]
