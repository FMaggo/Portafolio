# main.py
import pygame
from OpenGL.GL import *
from OpenGL.GLU import *
import sys
import requests
import random
from OpMat import OpMat
from OpMatR import OpMatR
from caja import Caja
from robot import Robot

# URL base de la API y obtención de datos
URL_BASE = "http://localhost:8000"
payload = {"dim": [40, 40]}  # Define la dimensión esperada en el servidor

try:
    r = requests.post(URL_BASE + "/simulations", json=payload, allow_redirects=False)
    datos = r.json()
    print("Datos iniciales:", datos)
except requests.exceptions.RequestException as e:
    print(f"Error al iniciar la simulación: {e}")
    sys.exit()

LOCATION = datos.get("Location")
if not LOCATION:
    print("No se encontró la ubicación de la simulación.")
    sys.exit()

# Función para filtrar `id` duplicados y asegurarse de que no se creen cajas con IDs de robots
def filtrar_ids_unicos_y_rellenar(datos, num_cajas=40):
    # Obtener los IDs de los robots
    ids_existentes = set(robot['id'] for robot in datos.get('robots', []))
    datos_filtrados = {'robots': datos.get('robots', []), 'boxes': {}}
    
    # Filtrar las cajas para que no tengan IDs que coincidan con robots
    for caja in datos.get('boxes', []):
        if caja['id'] not in ids_existentes:
            datos_filtrados['boxes'][caja['id']] = caja
            ids_existentes.add(caja['id'])
    
    # Generar cajas adicionales si faltan para llegar al número deseado
    id_nueva = max(ids_existentes, default=0) + 1
    while len(datos_filtrados['boxes']) < num_cajas:
        while id_nueva in ids_existentes:
            id_nueva += 1  # Asegurarse de no reutilizar IDs existentes
        nueva_caja = {
            'id': id_nueva,
            'pos': [random.randint(0, 39), random.randint(0, 39)]
        }
        datos_filtrados['boxes'][nueva_caja['id']] = nueva_caja
        ids_existentes.add(nueva_caja['id'])
        id_nueva += 1
    
    return datos_filtrados

# Filtrar los datos y asegurarse de que haya 40 cajas sin conflictos de ID
datos_unicos = filtrar_ids_unicos_y_rellenar(datos)

# Dimensiones del plano y límites de ejes
X_MIN, X_MAX = -450, 450
Y_MIN, Y_MAX = -450, 450

# Inicialización de objetos
opmat = OpMat()
opmatr = OpMatR()
cajas_normales = {}  # Diccionario de cajas normales: key = box_id, value = Caja object
robots = []          # Lista de robots
carried_boxes = {}   # Diccionario para cajas transportadas: key = box_id, value = Caja object

# Crear instancias de Robot primero para obtener los IDs de los robots
robot_ids = set()
for robot_data in datos_unicos["robots"]:
    robot_obj = Robot(opmatr, id=robot_data['id'], width=30, height=40)
    x_pos = (robot_data["pos"][0] - 1) * 20 - 400
    y_pos = (40 - robot_data["pos"][1]) * 20 - 400
    robot_obj.update_position(x_pos, y_pos)
    robots.append(robot_obj)
    robot_ids.add(robot_data['id'])

# Crear instancias de Caja y filtrar las que tienen IDs de robots
for box_id, box_data in datos_unicos["boxes"].items():
    caja_obj = Caja(opmat, id=box_id, width=20, height=20)
    x_pos = box_data["pos"][0] * 20 - 400
    y_pos = box_data["pos"][1] * 20 - 400
    caja_obj.update_position(x_pos, y_pos)
    cajas_normales[box_id] = caja_obj

def init():
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluOrtho2D(X_MIN, X_MAX, Y_MIN, Y_MAX)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    glClearColor(0.0, 0.0, 0.0, 0.0)
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)

def update_simulation_state():
    global cajas_normales, robots, carried_boxes
    try:
        r = requests.get(URL_BASE + LOCATION)
        data = r.json()

        # Validar que 'robots' y 'boxes' existan en los datos
        if 'robots' not in data or 'boxes' not in data:
            print("Datos incompletos recibidos del servidor.")
            return

        print("Datos recibidos del servidor:", data)
        
        # Actualizar posiciones de los robots y manejar cajas transportadas
        for i, robot_data in enumerate(data["robots"]):
            x_pos = (robot_data["pos"][0] - 1) * 20 - 400
            y_pos = (40 - robot_data["pos"][1]) * 20 - 400
            
            if i < len(robots):
                robots[i].update_position(x_pos, y_pos)
                print(f"Robot {robots[i].id} position updated to ({x_pos}, {y_pos})")
                # Manejar 'carrying_box' como booleano
                if robot_data["carrying_box"]:
                    robots[i].carrying_box_id = robot_data['id']  # Asumimos que la caja transportada tiene el mismo ID que el robot
                else:
                    robots[i].carrying_box_id = None

        # Reiniciar carried_boxes para actualizar con los nuevos datos
        carried_boxes = {}

        # Obtener todos los IDs de robots para gestionar las cajas transportadas
        robot_ids = set(robot.id for robot in robots)

        # Procesar las cajas que están siendo transportadas
        for robot in robots:
            if robot.carrying_box_id is not None:
                box_id = robot.carrying_box_id
                # Buscar la caja en cajas_normales y eliminarla
                caja_obj = cajas_normales.pop(box_id, None)
                if not caja_obj:
                    # Crear la caja si no existe
                    caja_obj = Caja(opmat, id=box_id, width=20, height=20)
                # Añadir la caja a carried_boxes con desplazamiento
                offset_x = 0    # Desplazamiento en el eje X
                offset_y = 20   # Desplazamiento en el eje Y
                caja_obj.update_position(robot.x_pos + offset_x, robot.y_pos + offset_y)
                carried_boxes[box_id] = caja_obj
                print(f"Caja {box_id} transportada por Robot {robot.id} en posición ({robot.x_pos + offset_x}, {robot.y_pos + offset_y})")

        # Crear un conjunto de IDs de cajas actuales del servidor
        server_box_ids = set(box['id'] for box in data["boxes"] if box['id'] not in robot_ids)

        # Actualizar las posiciones de las cajas no transportadas
        for box_data in data["boxes"]:
            box_id = box_data['id']
            if box_id in robot_ids:
                # Ya manejado en carried_boxes
                continue
            else:
                if box_id in cajas_normales:
                    # Actualizar posición existente
                    x_pos = box_data["pos"][0] * 20 - 400
                    y_pos = box_data["pos"][1] * 20 - 400
                    cajas_normales[box_id].update_position(x_pos, y_pos)
                    print(f"Caja {box_id} actualizada a posición ({x_pos}, {y_pos})")
                else:
                    # Crear nueva caja
                    x_pos = box_data["pos"][0] * 20 - 400
                    y_pos = box_data["pos"][1] * 20 - 400
                    nueva_caja = Caja(opmat, id=box_id, width=20, height=20)
                    nueva_caja.update_position(x_pos, y_pos)
                    cajas_normales[box_id] = nueva_caja
                    print(f"Nueva caja {nueva_caja.id} creada en posición ({x_pos}, {y_pos})")

        # Eliminar cajas que ya no están presentes en el servidor
        cajas_a_eliminar = set(cajas_normales.keys()) - server_box_ids
        for box_id in cajas_a_eliminar:
            del cajas_normales[box_id]
            print(f"Caja {box_id} eliminada de cajas_normales.")

    except requests.exceptions.RequestException as e:
        print(f"Error al actualizar el estado de la simulación: {e}")

def display():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    # Dibujar todas las cajas normales en blanco
    for caja_obj in cajas_normales.values():
        caja_obj.render()

    # Dibujar las cajas transportadas en azul con un desplazamiento relativo al robot
    for box_id, caja_obj in carried_boxes.items():
        robot = next((r for r in robots if r.id == box_id), None)
        if robot:
            glPushMatrix()
            # Establecer la posición del robot
            glTranslatef(robot.x_pos, robot.y_pos, 0)
            # Aplicar un desplazamiento para la caja transportada
            glTranslatef(0, 20, 0)  # Ajusta este valor según sea necesario
            caja_obj.render(color=(0.0, 0.0, 1.0))  # Color azul para cajas transportadas
            glPopMatrix()
            print(f"Caja {box_id} renderizada cerca del Robot {robot.id} en ({robot.x_pos}, {robot.y_pos})")

    # Dibujar los robots en rojo
    for robot_obj in robots:
        robot_obj.render(color=(1.0, 0.0, 0.0))

if __name__ == "__main__":
    # Inicializar pygame y configurar la ventana OpenGL
    pygame.init()
    screen = pygame.display.set_mode((600, 600), pygame.DOUBLEBUF | pygame.OPENGL)
    pygame.display.set_caption("Robots y Cajas")
    init()

    # Main loop
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()

        # Actualizar el estado de la simulación obteniendo datos del servidor
        update_simulation_state()

        # Llamar a la función de renderizado para actualizar la visualización
        display()

        # Intercambiar buffers y esperar para mantener la tasa de FPS (~60 FPS)
        pygame.display.flip()
        pygame.time.wait(500)  # Ajusta el intervalo de espera para sincronizar con las actualizaciones