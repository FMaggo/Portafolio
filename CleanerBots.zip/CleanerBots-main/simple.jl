using Agents, Random, Statistics

# Definición del agente Robot
@agent struct Robot(GridAgent{2, Float64})
    carrying_box::Bool = false
    direction::Symbol = :north
    last_drop_pos::Union{Tuple{Int, Int}, Nothing} = nothing  # Para evitar recoger la misma caja inmediatamente después de soltarla
    move_count::Int = 0  # Contador de movimientos
end

# Definición del agente Box
@agent struct Box(GridAgent{2, Float64})
    box_count::Int
end

# Paso de agente para Box (no realiza ninguna acción)
function agent_step!(agent::Box, model)
    # Las cajas no realizan acciones
end

# Paso de agente para Robot
function agent_step!(agent::Robot, model)
    directions = Dict(
        :north => (0, 1),
        :south => (0, -1),
        :east => (1, 0),
        :west => (-1, 0)
    )
    
    current_pos = agent.pos
    move = directions[agent.direction]
    new_pos = current_pos .+ move
    
    # Verifica si el movimiento está dentro de los límites de la cuadrícula (hasta y = 39)
    if 1 ≤ new_pos[1] ≤ 40 && 1 ≤ new_pos[2] ≤ 39
        # Verifica si hay una caja en la dirección que se va a mover
        for other in agents_in_position(new_pos, model)
            if other isa Box && !agent.carrying_box && other.pos != agent.last_drop_pos
                agent.carrying_box = true
                println("Robot $(agent.id) ha recogido una caja en la dirección $(agent.direction).")
                remove_agent!(other, model)  # Elimina la caja del espacio
                break
            end
        end
        
        # Mueve al robot y cuenta el movimiento
        move_agent!(agent, new_pos, model)
        agent.move_count += 1
    else
        # Si el movimiento está fuera de los límites, cambia la dirección del robot
        agent.direction = rand([:north, :south, :east, :west])
    end
    
    # Cuando el robot llega a la línea 39 y suelta la caja
    if agent.carrying_box && agent.pos[2] == 39
        agent.carrying_box = false
        agent.last_drop_pos = agent.pos  # Guarda la posición de la última caja soltada
        println("Robot $(agent.id) ha dejado una caja en la pared norte en la posición $(agent.pos).")
        
        # Apila cajas en la posición norte con un máximo de 5
        stack_count = sum([other.box_count for other in agents_in_position(agent.pos, model) if other isa Box])
        if stack_count < 5
            add_agent!(Box, model; pos=agent.pos, box_count=1)  # Agrega una nueva caja
        end
        
        # Da 3 pasos hacia el sur después de dejar la caja
        for _ in 1:3
            new_south_pos = agent.pos .+ directions[:south]
            if 1 ≤ new_south_pos[1] ≤ 40 && 1 ≤ new_south_pos[2] ≤ 39
                move_agent!(agent, new_south_pos, model)
                agent.move_count += 1
            end
        end
    end
    
    # Lógica para cambiar la dirección aleatoriamente después de soltar la caja
    if !agent.carrying_box
        if agent.pos[2] == 39
            # Si el robot está en la línea 39, evita que vaya más al norte
            agent.direction = rand([:south, :east, :west])
        else
            # Permite que el robot se mueva en cualquier dirección
            agent.direction = rand([:north, :south, :east, :west])
        end
    end
end

# Función para inicializar el modelo
function initialize_model(griddims = (40, 40), max_boxes = 40)
    space = GridSpace(griddims; periodic=false, metric = :manhattan)
    model = ABM(
        Union{Box, Robot}, 
        space, 
        scheduler = Schedulers.ByType(true, true, Union{Box, Robot}), 
        agent_step! = agent_step!)
    
    all_positions = [pos for pos in positions(model) if pos[2] <= griddims[2] - 3]
    shuffled_positions = shuffle!(all_positions)

    selected_positions = shuffled_positions[1:min(max_boxes, length(shuffled_positions))]
    for pos in selected_positions
        add_agent!(Box, model; pos=pos, box_count=1)
    end

    available_positions = setdiff(all_positions, selected_positions)
    robot_positions = available_positions[1:5]
    for pos in robot_positions
        add_agent!(Robot, model; pos=pos, carrying_box=false)
    end

    return model
end

# Función para calcular estadísticas
function calculate_statistics(model)
    robots = [agent for agent in allagents(model) if agent isa Robot]
    move_counts = [robot.move_count for robot in robots]

    avg_moves = mean(move_counts)
    std_moves = std(move_counts)

    println("Promedio de movimientos: $avg_moves")
    println("Desviación estándar de movimientos: $std_moves")
end
