import React, { useEffect, useState } from 'react';
import Button from '@mui/material/Button';

import socket from '../services/taxi_socket';
import { Card, CardContent, Grid, Typography } from '@mui/material';

function Driver(props) {
	let [message, setMessage] = useState();
	let [bookingId, setBookingId] = useState();
	let [visible, setVisible] = useState(false);
	useEffect(() => {
		let channel = socket.channel('driver:' + props.username, { token: '123' });
		channel.on('booking_request', data => {
			console.log('Received', data);
			setMessage(data.msg);
			setBookingId(data.bookingId);
			setVisible(true);
		});
		channel.on('withdraw', data => {
			setVisible(false);
		});
		channel.join();
	}, [props]);

	let reply = decision => {
		fetch(`http://localhost:4000/api/bookings/${bookingId}`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ action: decision, username: props.username }),
		}).then(resp => setVisible(false));
	};

	let notifyArrival = () => {
		fetch(`http://localhost:4000/api/bookings/${bookingId}`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({
				action: 'notify_arrival',
				username: props.username,
			}),
		}).then(resp => setVisible(false));
	};

	return (
		<div style={{ textAlign: 'center', borderStyle: 'solid' }}>
			Driver: {props.username}
			<Grid container>
				<Grid item xl="2">
					<Button onClick={notifyArrival} variant="outlined" color="secondary">
						Notify arrival
					</Button>
				</Grid>
				<Grid
					item
					style={{ backgroundColor: 'lavender', height: '100px' }}
					xl="10"
				>
					{visible ? (
						<Card variant="outlined" style={{ margin: 'auto', width: '600px' }}>
							<CardContent>
								<Typography>{message}</Typography>
							</CardContent>
							<Button
								onClick={() => reply('accept')}
								variant="outlined"
								color="primary"
							>
								Accept
							</Button>
							<Button
								onClick={() => reply('reject')}
								variant="outlined"
								color="secondary"
							>
								Reject
							</Button>
						</Card>
					) : null}
				</Grid>
			</Grid>
		</div>
	);
}

export default Driver;
