defmodule TaxiBeWeb.TaxiAllocationJob do
  use GenServer

  @moduledoc """
  Este módulo gestiona la asignación de taxis a los clientes mediante el uso de un servidor GenServer.
  """

  @doc """
  Inicia el GenServer con una solicitud específica y un nombre de proceso.

  ## Parámetros:

  - `request`: El pedido de taxi realizado por el cliente.
  - `name`: Nombre del proceso.
  """
  def start_link(request, name) do
    GenServer.start_link(__MODULE__, request, name: name)
  end

  @doc """
  Inicializa el estado del GenServer y envía el primer mensaje `:step1`.

  ## Parámetros:

  - `request`: El pedido de taxi realizado por el cliente.
  """
  def init(request) do
    Process.send(self(), :step1, [:nosuspend])
    {:ok, %{request: request, st: :none}}
  end

  @doc """
  Gestiona varios mensajes que se envían al GenServer.
  """

  # Maneja el mensaje `:step1`
  @doc """
  Selecciona un taxi candidato y notifica al cliente la tarifa del viaje.

  ## Parámetros:

  - `:step1`: El mensaje de selección del primer paso.
  - `state`: El estado actual del GenServer.
  """
  def handle_info(:step1, %{request: request}) do
    task = Task.async(fn -> compute_ride_fare(request) |> notify_customer_ride_fare() end)
    Task.await(task)
    taxis = select_candidate_taxis(request)

    Process.send(self(), :block1, [:nosuspend])

    {:noreply, %{request: request, candidates: taxis, st: :none}}
  end

  # Maneja el mensaje `:block1`
  @doc """
  Contacta al primer taxi candidato y le envía una solicitud de reserva.

  ## Parámetros:

  - `:block1`: El mensaje de contacto del taxi.
  - `state`: El estado actual del GenServer.
  """
  def handle_info(:block1, %{request: request, candidates: taxis}) do
    %{
      "pickup_address" => pickup_address,
      "dropoff_address" => dropoff_address,
      "booking_id" => booking_id
    } = request

    taxis
    |> Enum.map(fn taxi ->
      TaxiBeWeb.Endpoint.broadcast(
        "driver:" <> taxi.nickname,
        "booking_request",
        %{
          msg: "Viaje de '#{pickup_address}' a '#{dropoff_address}'",
          bookingId: booking_id
        }
      )
    end)

    timer_id = Process.send_after(self(), :timeout1, 90000)

    {:noreply, %{request: request, candidates: taxis, timer: timer_id, st: NoPenalty}}
  end

  # Maneja el mensaje `:timeout1`
  @doc """
  Maneja el tiempo de espera para la respuesta del taxi contactado.

  ## Parámetros:

  - `:timeout1`: El mensaje de tiempo de espera.
  - `state`: El estado actual del GenServer.
  """
  def handle_info(:timeout1, %{request: request, candidates: taxis} = state) do
    # Enviar a cada taxi el mensaje de retirar su ventana para aceptar o rechazar viaje
    taxis
    |> Enum.map(fn taxi ->
      TaxiBeWeb.Endpoint.broadcast(
        "driver:" <> taxi.nickname,
        "withdraw",
        %{}
      )
    end)

    # Si expira el temporizador, notificar al cliente que no hay taxis
    TaxiBeWeb.Endpoint.broadcast("customer:" <> request["username"], "booking_request", %{
      msg: "No hay conductores disponibles."
    })

    {:noreply, %{state | candidates: []}}
  end

  @spec compute_ride_fare(map()) :: {map(), float()}
  @doc """
  Calcula la tarifa del viaje basado en las direcciones de recogida y destino.

  ## Parámetros:

  - `request`: La solicitud de reserva del cliente.

  ## Retorna:

  - Una tupla con la solicitud original y la tarifa calculada.
  """
  def compute_ride_fare(request) do
    %{
      "pickup_address" => pickup_address,
      "dropoff_address" => dropoff_address
    } = request

    coord1 = TaxiBeWeb.Geolocator.geocode(pickup_address)
    coord2 = TaxiBeWeb.Geolocator.geocode(dropoff_address)
    {distance, _duration} = TaxiBeWeb.Geolocator.distance_and_duration(coord1, coord2)
    {request, Float.ceil(distance / 80)}
  end

  def compute_driver_eta(
        {_, [_longitude_driver, _latitude_driver]} = driver_coords,
        pickup_address
      ) do
    pickup_coords = TaxiBeWeb.Geolocator.geocode(pickup_address)

    {_distance, duration} =
      TaxiBeWeb.Geolocator.distance_and_duration(driver_coords, pickup_coords)

    duration
  end

  @doc """
  Notifica al cliente la tarifa calculada del viaje.

  ## Parámetros:

  - `{request, fare}`: Una tupla con la solicitud original y la tarifa calculada.
  """
  def notify_customer_ride_fare({request, fare}) do
    %{"username" => customer} = request

    TaxiBeWeb.Endpoint.broadcast("customer:" <> customer, "booking_request", %{
      msg: "Ride fare: #{fare}"
    })
  end

  @doc """
  Maneja la aceptación del viaje por parte del conductor.

  ## Parámetros:

  - `{:process_accept, _driver_username}`: El mensaje de aceptación del conductor.
  - `state`: El estado actual del GenServer.
  """
  def handle_cast(
        {:process_accept, driver_username},
        %{request: request, candidates: candidates, timer: timer_id} = state
      ) do
    %{"username" => username} = request

    # Dado el nombre del conductor encontrar sus coords
    driver = candidates |> Enum.find(fn taxi -> taxi.nickname == driver_username end)

    duration =
      compute_driver_eta({:ok, [driver.longitude, driver.latitude]}, request["pickup_address"])

    display_duration = trunc(Float.ceil(duration / 60))

    TaxiBeWeb.Endpoint.broadcast("customer:" <> username, "booking_request", %{
      msg:
        "Tu taxi esta en camino. El conductor es #{driver_username} y tarda #{display_duration} min"
    })

    candidates
    |> Enum.map(fn taxi ->
      TaxiBeWeb.Endpoint.broadcast("driver:" <> taxi.nickname, "withdraw", %{})
    end)

    # deshabilitar timer
    Process.cancel_timer(timer_id)

    # Iniciar timer para penalizar al conductor, el tiempo que tarde en llegar el conductor menos tres minutos, en milisegundos
    time_to_penalty = (display_duration - 3) * 60 * 1000

    # nuevo timer para cambiar el estado de penalizacion.
    timer_id = Process.send_after(self(), :timeout_penalty, time_to_penalty)

    {:noreply, %{state | st: NoPenalty, timer: timer_id}}
  end

  def handle_info(
        :timeout_penalty,
        %{timer: timer_id} = state
      ) do
    Process.cancel_timer(timer_id)

    {:noreply, %{state | st: Penalty, timer: nil}}
  end

  @doc """
  Maneja el rechazo del viaje por parte del conductor.

  ## Parámetros:

  - `{:process_reject, _driver_username}`: El mensaje de rechazo del conductor.
  - `state`: El estado actual del GenServer.
  """
  def handle_cast(
        {:process_reject, driver_username},
        %{request: request, candidates: taxis} = state
      ) do
    # Quitar conductor que rechazó de la lista de candidatos
    new_candidates = Enum.reject(taxis, fn taxi -> taxi.nickname == driver_username end)

    # Withdraw driver that rejected
    TaxiBeWeb.Endpoint.broadcast(
      "driver:" <> driver_username,
      "withdraw",
      %{
        msg: "Viaje rechazado"
      }
    )

    if new_candidates == [] do
      TaxiBeWeb.Endpoint.broadcast("customer:" <> request["username"], "booking_request", %{
        msg: "No hay conductores disponibles."
      })
    end

    {:noreply, %{state | candidates: new_candidates}}
  end

  def handle_cast({:process_cancel, username}, %{candidates: taxis, timer: timer_id} = state) do
    msg_value =
      if state.st == Penalty,
        do: "Viaje cancelado con penalizacion de $20",
        else: "Viaje cancelado sin penalizacion"

    TaxiBeWeb.Endpoint.broadcast("customer:" <> username, "booking_request", %{
      msg: msg_value
    })

    # Withdraw all drivers
    taxis
    |> Enum.map(fn taxi ->
      TaxiBeWeb.Endpoint.broadcast("driver:" <> taxi.nickname, "withdraw", %{})
    end)

    # Cancelar timer de respuesta de conductores para evitar que aparezca no hay conductores disponibles una vez se cancela el viaje
    Process.cancel_timer(timer_id)

    {:noreply, state}
  end

  def handle_cast({:notify_arrival, username}, %{request: request} = state) do
    TaxiBeWeb.Endpoint.broadcast("customer:" <> request["username"], "booking_request", %{
      msg: "Tu conductor #{username} ha llegado por ti"
    })

    {:noreply, state}
  end

  @doc """
  Selecciona los taxis candidatos en base a la dirección de recogida.

  ## Parámetros:

  - `request`: La solicitud de reserva del cliente.

  ## Retorna:

  - Una lista de taxis candidatos.
  """
  def select_candidate_taxis(%{"pickup_address" => _pickup_address}) do
    [
      # Angelopolis
      %{nickname: "frodo", latitude: 19.0319783, longitude: -98.2349368},
      # Via San Angel
      %{nickname: "samwise", latitude: 19.0061167, longitude: -98.2697737},
      # Paseo Destino
      %{nickname: "merry", latitude: 19.0092933, longitude: -98.2473716}
    ]
  end
end
