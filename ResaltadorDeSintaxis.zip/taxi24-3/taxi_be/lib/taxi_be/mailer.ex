defmodule TaxiBe.Mailer do
  use Swoosh.Mailer, otp_app: :taxi_be
end
