# robot.py
from OpenGL.GL import *
from draw import draw_line

class Robot:
    def __init__(self, opmatr, id, width=30, height=40):
        self.opmatr = opmatr  # Referencia al objeto OpMat
        self.id = id  # Identificador único
        self.carrying_box_id = None
        w = width / 2.0
        h = height / 2.0
        self.position = [0, 0]
        self.base_points = [(-w, -h), (w, -h), (w, h), (-w, h)]  # Puntos base del cuerpo del robot
        self.angle = 0  # Ángulo de rotación

        # Definir las antenas como subcomponentes
        self.antenna1 = {
            'base_points': [(-1, -7.5), (1, -7.5), (1, 7.5), (-1, 7.5)],
            'offset': [-10, 20]
        }
        self.antenna2 = {
            'base_points': [(-1, -7.5), (1, -7.5), (1, 7.5), (-1, 7.5)],
            'offset': [10, 20]
        }

    @property
    def x_pos(self):
        return self.position[0]

    @property
    def y_pos(self):
        return self.position[1]

    def update_position(self, x, y):
        """Actualizar la posición del robot a nuevas coordenadas x, y."""
        self.position = [x, y]

    def render_component(self, base_points, color=(1.0, 1.0, 1.0)):
        """
        Renderiza un componente dado por los puntos base.

        Parameters:
        base_points (list): Lista de puntos base a transformar y dibujar.
        color (tuple): Color RGB a usar (por defecto blanco).
        """
        glColor3f(*color)  # Establece el color
        transformed_points = self.opmatr.mult_points(base_points)
        
        # Dibuja el rectángulo conectando los puntos transformados
        draw_line(transformed_points[0], transformed_points[1])
        draw_line(transformed_points[1], transformed_points[2])
        draw_line(transformed_points[2], transformed_points[3])
        draw_line(transformed_points[3], transformed_points[0])

    def render(self, color=(1.0, 0.0, 0.0)):  # Color rojo por defecto
        glPushMatrix()  # Guarda el estado actual de OpenGL
        glTranslatef(self.position[0], self.position[1], 0)  # Translada a la posición del robot
        glRotatef(self.angle, 0, 0, 1)  # Aplica rotación

        # Renderiza el cuerpo del robot
        self.render_component(self.base_points, color)

        # Renderiza la antena izquierda
        glPushMatrix()
        glTranslatef(self.antenna1['offset'][0], self.antenna1['offset'][1], 0)  # Translada para la antena
        self.render_component(self.antenna1['base_points'], color)
        glPopMatrix()

        # Renderiza la antena derecha
        glPushMatrix()
        glTranslatef(self.antenna2['offset'][0], self.antenna2['offset'][1], 0)  # Translada para la antena
        self.render_component(self.antenna2['base_points'], color)
        glPopMatrix()

        glPopMatrix()  # Restaura el estado anterior de OpenGL