# Programa principal para el análisis de secuencias de ADN.
# Autores:
# - Jonathan Armando Arredondo Hernandez
# - Diego Javier Solorzano Trinidad
# - Fernando Maggi Llerandi
# - Rusbel Alejandro Morales Mendez
# Fecha de creación: 1/11/2024

from colorama import Fore
from findPalindromes import findPalindromes
from highlightSimilarities import highlightSimilarities
from processAllPairs import processAllPairs
from read_dataset import readDataset

def main():
    """
    Función principal que ejecuta el análisis de secuencias de ADN, incluyendo:
    búsqueda de subsecuencias, detección de palíndromos, cálculo de substring
    común más largo y generación de una matriz de similitud.
    """

    directory = 'data'  # Cambia a la ruta real del directorio
    dataset = readDataset(directory)
    results = processAllPairs(dataset)

    # Ordena los resultados en orden descendente según la métrica de similitud
    sortedResults = sorted(results, key=lambda x: x['similarity_metric'], reverse=True)
    top10Pairs = sortedResults[:10]

    # Parte 2: Detección de Palíndromos
    minPalindromeLength = 4
    print(Fore.CYAN + "\n--- Detección de Palíndromos ---")
    for filename, sequence in dataset.items():
        palindromes = findPalindromes(sequence, minLength=minPalindromeLength)
        print(f"{filename} - Palíndromos:")
        for palindrome, pos in palindromes:
            print(f"   {Fore.GREEN}Palíndromo '{palindrome}' en posición {pos}")

    # Parte 1 y 3: Búsqueda de subsecuencias y substring común más largo, resaltado y matriz de similitud
    print(Fore.CYAN + "\n--- Substring Más Largo Común y Matriz de Similitud ---")
    for index, pair in enumerate(top10Pairs, 1):
        file1 = pair['file1']
        file2 = pair['file2']
        similarityMetric = pair['similarity_metric']
        print(f"\nPar {index}: {file1} y {file2}")
        print(f"Métrica de Similitud: {similarityMetric:.2f}%")
        highlightSimilarities(dataset[file1], dataset[file2])

if __name__ == '__main__':
    main()