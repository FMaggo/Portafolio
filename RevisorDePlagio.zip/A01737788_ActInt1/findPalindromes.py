# Descripción breve del programa:
# Función para encontrar palíndromos en una secuencia de texto dada, con una longitud mínima especificada.
# Autor: Autor: Fernando Maggi Llerandi | A01736935
# Fecha de creación/modificación: 31/10/2024

def findPalindromes(sequence, minLength=3):
    """
    Encuentra y almacena los palíndromos presentes en una secuencia de texto, con una longitud mínima especificada.
    
    La función recorre la secuencia buscando subcadenas que sean palíndromos, es decir, que se lean igual de 
    izquierda a derecha y viceversa. Cada palíndromo encontrado se almacena junto a su índice inicial en la secuencia.
    
    Parámetros:
    - sequence (str): Secuencia de texto en la cual se buscan los palíndromos.
    - minLength (int): Longitud mínima de los palíndromos a identificar (por defecto es 3).
    
    Retorna:
    - list: Lista de tuplas, donde cada tupla contiene el palíndromo encontrado y su índice inicial en la secuencia.
    """
    palindromes = []  # Lista para almacenar los palíndromos encontrados
    n = len(sequence)  # Longitud de la secuencia

    for i in range(n):
        for j in range(i + minLength, n + 1):
            # Extrae una subcadena desde el índice i hasta el índice j
            substring = sequence[i:j]
            
            # Verifica si la subcadena es un palíndromo
            if substring == substring[::-1]:
                palindromes.append((substring, i))  # Almacena el palíndromo y su índice inicial

    return palindromes