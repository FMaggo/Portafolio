"""
Programa para la construcción de suffix y LCP arrays para análisis de similitud de textos.
Autores: Diego Javier Solorzano Trinidad
Fecha de creación/modificación: 29/10/2024

Descripción: Este archivo contiene la función computeLcpArray que calcula el LCP (Longest Common Prefix)
array para una cadena dada y su suffix array. Esta estructura es utilizada en algoritmos de procesamiento
de texto para identificar subcadenas comunes de manera eficiente.
"""

def computeLcpArray(cadena, suffixArray):
    """
    Calcula el LCP (Longest Common Prefix) array para una cadena y su suffix array dado.

    Parámetros:
    cadena (str): Cadena de texto sobre la cual se calcula el LCP array.
    suffixArray (list): Suffix array de la cadena, representando posiciones de sufijos ordenados.

    Valor de retorno:
    list: LCP array que contiene las longitudes de los prefijos comunes más largos entre sufijos consecutivos
          en el suffix array.
    """
    
    longitud = len(cadena)  # Longitud de la cadena
    rango = [0] * longitud  # Array para almacenar el rango de cada sufijo en el suffix array
    
    # Asignar el rango correspondiente a cada sufijo en el suffix array
    for i in range(longitud):
        rango[suffixArray[i]] = i

    lcpArray = [0] * (longitud - 1)  # Inicialización del LCP array
    h = 0  # Variable auxiliar para almacenar la longitud del prefijo común más largo

    # Calcular el LCP para cada sufijo, basado en su rango en el suffix array
    for i in range(longitud):
        if rango[i] > 0:
            j = suffixArray[rango[i] - 1]  # Obtener el sufijo anterior en el orden del suffix array

            # Calcular la longitud del prefijo común más largo entre los sufijos en i y j
            while (i + h < longitud) and (j + h < longitud) and (cadena[i + h] == cadena[j + h]):
                h += 1

            lcpArray[rango[i] - 1] = h  # Almacenar la longitud en el LCP array
            
            # Optimización: reducir h para la siguiente iteración, si es mayor que 0
            if h > 0:
                h -= 1

    return lcpArray