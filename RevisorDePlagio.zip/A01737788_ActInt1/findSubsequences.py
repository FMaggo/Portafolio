"""
Programa para la búsqueda de subsecuencias en una cadena.
Autor: Diego Javier Solorzano Trinidad
Fecha de creación/modificación: 30/10/24

Descripción: Este archivo contiene la función findSubsequences que busca todas las ocurrencias de una 
subsecuencia específica en una cadena y devuelve las posiciones donde se encuentra.
"""

def findSubsequences(secuencia, subSecuencia):
    """
    Busca todas las ocurrencias de una subsecuencia específica en una cadena y devuelve las posiciones donde se encuentra.

    Parámetros:
    secuencia (str): La cadena de texto en la que se realizará la búsqueda.
    subSecuencia (str): La subsecuencia que se desea buscar en la cadena.

    Valor de retorno:
    list: Una lista de posiciones (índices) donde la subsecuencia se encuentra en la cadena.
    """
    
    posiciones = []  # Lista para almacenar las posiciones donde se encuentra la subsecuencia
    longitudSub = len(subSecuencia)  # Longitud de la subsecuencia

    # Iterar sobre la secuencia para encontrar todas las ocurrencias de la subsecuencia
    for i in range(len(secuencia) - longitudSub + 1):
        if secuencia[i:i + longitudSub] == subSecuencia:
            posiciones.append(i)  # Agregar la posición a la lista si hay coincidencia

    return posiciones