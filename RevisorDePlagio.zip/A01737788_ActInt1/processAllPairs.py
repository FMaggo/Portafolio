
import itertools

from similarityMetric import similarityMetric

# Descripción: Este archivo procesa todas las combinaciones de pares de archivos y obtiene su métrica de similitud.
# Autor: Rusbel Alejandro Morales Méndez - Matrícula: A01737814
# Fecha de creación/modificación: 31/10/2024

def processAllPairs(data): # data es un diccionario con los nombres de los archivos como llaves y su contenido como valores.
    results = []
    files = list(data.keys()) # Obtiene los nombres de los archivos.
    for (file1, file2) in itertools.combinations(files, 2):
        content1 = data[file1] # Obtiene el contenido del archivo 1.
        content2 = data[file2] # Obtiene el contenido del archivo 2.
        simMetric = similarityMetric(content1, content2) # Obtiene la métrica de similitud.
        results.append({'file1': file1, 'file2': file2, 'similarity_metric': simMetric})
    return results

# git commit -m "Implementacion de la funcion processAllPairs que obtiene la similitud entre todos los pares de archivos"