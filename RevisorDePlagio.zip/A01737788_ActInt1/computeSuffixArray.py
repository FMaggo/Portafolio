# Descripción: Este archivo calcula y se obtiene un array de sufijos de una cadena de texto.
# Autor: Rusbel Alejandro Morales Méndez
# Fecha de creación/modificación: 30/10/2024

# Función que calcula el array de sufijos de una cadena de texto
def computeSuffixArray(string):
    # Crear lista de sufijos y sus índices
    suffixes = [(string[i:], i) for i in range(len(string))]
    sortedSuffixes = sorted(suffixes)  # Ordenar sufijos léxicograficamente
    suffixArray = [suffix[1] for suffix in sortedSuffixes]  # Obtener solo los índices ordenados
    return suffixArray