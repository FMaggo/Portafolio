'use client'
import { useRef, useState } from "react";
import styles from "./page.module.css";
import AverageSpeedChart from './AverageSpeedChart';

export default function Home() {
  let [location, setLocation] = useState("");
  let [trafficLights, setTrafficLights] = useState([]);
  let [cars, setCars] = useState([]);
  let [simSpeed, setSimSpeed] = useState(10);
  let [averageSpeedData, setAverageSpeedData] = useState([]);
  const running = useRef(null);
  let simulationStep = useRef(0);

  let setup = () => {
    console.log("Iniciando la configuración...");

    // Limpiar el estado antes de la configuración
    setCars([]);
    setTrafficLights([]);
    setAverageSpeedData([]);
    fetch("http://localhost:8000/simulations", {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}) // Enviar una solicitud vacía
    })
    .then(resp => {
      console.log("Respuesta completa del servidor:", resp);
      return resp.json();
    })
    .then(data => {
      console.log("Datos recibidos del servidor:", data);
      if (data.error) {
        console.error("Error del servidor:", data.error);
      } else {
        setLocation(data["Location"]);
        setCars(data["cars"]);
        setTrafficLights(data["trafficLights"]);
      }
    })
    .catch(error => {
      console.error("Error al procesar la solicitud:", error);
    });
  };

  const handleStart = () => {
    if (!running.current) {
      running.current = setInterval(() => {
        console.log("Iniciando simulación en la ubicación:", location);

        fetch("http://localhost:8000" + location)
        .then(res => res.json())
        .then(data => {
          console.log("Datos actualizados:", data);
          setCars(data["cars"]);
          setTrafficLights(data["trafficLights"]);

          // Calcular la velocidad promedio
          const totalSpeed = data["cars"].reduce((acc, car) => acc + car.current_speed, 0);
          const avgSpeed = data["cars"].length > 0 ? (totalSpeed / data["cars"].length).toFixed(2) : 0;

          // Actualizar los datos de la gráfica
          setAverageSpeedData((prevData) => [
            ...prevData,
            { time: simulationStep.current, averageSpeed: parseFloat(avgSpeed) }
          ]);

          simulationStep.current += 1; // Incrementar el contador de tiempo
        })
        .catch(error => console.error("Error durante la simulación:", error));
      }, 1000 / simSpeed);
    }
  };

  const handleStop = () => {
    clearInterval(running.current);
    running.current = null;
    console.log("Simulación detenida");
  };

  return (
    <main className={styles.main}>
      <div>
        <button variant={"contained"} onClick={setup}>
          Setup
        </button>
        <button variant={"contained"} onClick={handleStart}>
          Start
        </button>
        <button variant={"contained"} onClick={handleStop}>
          Stop
        </button>
      </div>
      <svg width="800" height="500" xmlns="http://www.w3.org/2000/svg" style={{ backgroundColor: "white" }}>
        {/* Calles horizontales y verticales */}
        <rect x={0} y={200} width={800} height={80} style={{ fill: "darkgray" }} />
        <rect x={360} y={0} width={80} height={500} style={{ fill: "darkgray" }} />

        {/* Semáforos */}
        {trafficLights && trafficLights.length > 0 && trafficLights.map((light) => (
          <circle
            key={light.id}
            cx={light.pos[0] * 32}
            cy={light.pos[1] * 20}
            r={10}
            fill={light.state === "green" ? "green" : light.state === "yellow" ? "yellow" : "red"}
          />
        ))}

        {/* Coches */}
        {cars && cars.length > 0 && cars.map((car) => {
          const xPos = car.pos[0] * 32;
          const yPos = car.pos[1] * 20;
          const rotation = car.direction === 'vertical' ? -90 : 0; // Rotar si el coche es vertical

          return (
            <image
              key={car.id}
              id={car.id}
              x={xPos}
              y={yPos}
              width={32}
              height={32} // Asegurarse de establecer la altura
              transform={`rotate(${rotation}, ${xPos + 16}, ${yPos + 16})`} // Rotar alrededor del centro de la imagen
              href={car.id === 1 ? "./dark-racing-car.png" : './racing-car.png'}
            />
          );
        })}
      </svg>

      {/* Área de la Gráfica */}
      <div style={{ width: "600px", height: "400px", marginLeft: "20px" }}>
        <AverageSpeedChart data={averageSpeedData} />
      </div>
    </main>
  );
}
